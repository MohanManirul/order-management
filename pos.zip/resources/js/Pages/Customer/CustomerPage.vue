<script setup>
import SideNavLayout from '../../Layout/SideNavLayout.vue'
import CustomerList from '../../Components/Customer/CustomerList.vue'
</script>

<template>
 <SideNavLayout>
    <CustomerList/>
 </SideNavLayout>

</template>

<style scoped>

</style>

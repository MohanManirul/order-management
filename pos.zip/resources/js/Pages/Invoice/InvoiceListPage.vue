<script setup>
import InvoiceList from '../../Components/Invoice/InvoiceList.vue'
import SideNavLayout from '../../Layout/SideNavLayout.vue'
</script>

<template>
<SideNavLayout>
    <InvoiceList/>
</SideNavLayout>
</template>

<style scoped>

</style>

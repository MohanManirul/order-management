<script setup>
import SideNavLayout from '../../Layout/SideNavLayout.vue'
import UserListForm from '../../Components/User/UserListForm.vue'

</script>

<template>
<SideNavLayout>
    <UserListForm/>
</SideNavLayout>
</template>

<style scoped>

</style>

<script setup>

import SideNavLayout from '../../Layout/SideNavLayout.vue'
import UserSaveForm from '../../Components/User/UserSaveForm.vue'

</script>

<template>
<SideNavLayout>
    <UserSaveForm/>
</SideNavLayout>

</template>

<style scoped>

</style>

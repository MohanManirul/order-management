<script setup>
import SideNavLayout from '../../Layout/SideNavLayout.vue'
import CreateSaleForm from '../../Components/Sale/CreateSaleForm.vue'
</script>

<template>
<SideNavLayout>
    <CreateSaleForm/>
</SideNavLayout>

</template>

<style scoped>

</style>]

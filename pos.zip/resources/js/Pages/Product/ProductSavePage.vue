<script setup>
import SideNavLayout from '../../Layout/SideNavLayout.vue'
import ProductSaveForm from '../../Components/Product/ProductSaveForm.vue'
</script>

<template>
 <SideNavLayout>
    <ProductSaveForm/>
 </SideNavLayout>
</template>

<style scoped>

</style>
